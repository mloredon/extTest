package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.And;

public class PayablesPage {

	private WebDriver driver;

	// 2. Constructor of the page class:
	public PayablesPage(WebDriver driver) {
		this.driver = driver;
	}

	@And("click on group payables")
	public void click_on_group_payable_button() {
	   System.out.println("Step3: user is clicking on Login Button");
	   driver.findElement(By.name("btnActive")).click();
	}

	

}
