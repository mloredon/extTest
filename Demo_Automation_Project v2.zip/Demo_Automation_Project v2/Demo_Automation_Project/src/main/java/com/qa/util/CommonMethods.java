package com.qa.util;


import io.cucumber.java.Scenario;



public class CommonMethods {

static Scenario sc;


	public void delay() {

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
	
	
}
