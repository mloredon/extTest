package stepdefinitions;

import java.io.IOException;
import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.pages.LoginPage;
import com.qa.factory.DriverFactory;
import com.qa.util.CommonMethods;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageSteps {
	CommonMethods cm;
	private static String title;
	private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
	Properties prop;
	private WebDriver driver;
	
	//public LoginPageSteps()
	//{} 
	
	//public LoginPageSteps(WebDriver drivers)
	//{
	//	this.driver = drivers;
	//}
	//
	@Given("I verify the input field {string} is present")
	public void i_verify_input_field_is_displayed(String strFieldName) throws IOException {
		loginPage.userNameExists();
	}
	
	@Given("I verify the link {string} is present")
	public void i_verify_the_link_is_displayed(String strFieldName) throws IOException {

		loginPage.passwordExists();
	}
	
	@Given("I verify the button {string} is present")
	public void i_verify_button_is_displayed(String strFieldName) throws IOException {

		loginPage.loginButtonExists();
	}
	
	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page()  throws IOException{
		title = loginPage.getLoginPageTitle();
		System.out.println("Page title is: " + title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedTitleName) {
		Assert.assertTrue(title.contains(expectedTitleName));
	}

	
	@When("user login the application with {string} and {string}")
	public void user_login_the_application_with(String Uname, String pass) throws IOException {
		//String username = prop.getProperty("userName");
		//String password = prop.getProperty("password");
		//System.out.print( "UseerName : "+username);
		loginPage.enterUserName(Uname);
		loginPage.enterPassword(pass);
		loginPage.clickOnLogin();
	}
	
	@When("I enter the details in invoice header {string} and {string} and {string}")
	public void Enter_Invoice_Details(String invoicenumber, String Ccy, String amount) throws InterruptedException 
	{
		System.out.print("0");
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
			System.out.print(e);
				}
		
	//	Select sc = new Select(driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:soc1::content")));
		System.out.print("1");
		
		
		
		loginPage.enterValues(invoicenumber,  Ccy,  amount);
		
		
		//cm.delay();
		//driver.findElement(By.xpath("//a[.='Billing']")).click();
		
	}
	
}
