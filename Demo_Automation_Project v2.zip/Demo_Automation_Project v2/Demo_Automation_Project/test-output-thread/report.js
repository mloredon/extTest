$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "59d8cb7e-316f-40eb-abcc-9ee6d90b5857",
    "feature": "Verification of login functionality",
    "scenario": "Verify Login functionality",
    "start": 1646716862040,
    "group": 1,
    "content": "",
    "tags": "@demotest,",
    "end": 1646716875182,
    "className": "failed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});